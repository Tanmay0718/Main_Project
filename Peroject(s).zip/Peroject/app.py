from flask import Flask, request, jsonify
import openai
import requests
import os
from dotenv import load_dotenv

# Load API keys from .env file
load_dotenv()

app = Flask(__name__)

# Set up API credentials
NUTRITIONIX_APP_ID = os.getenv('a68c0f2c')
NUTRITIONIX_API_KEY = os.getenv('1099f51cd55e08ca9ab149e50cb92b75')
OPENAI_API_KEY = os.getenv('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')

@app.route('/analyze', methods=['POST'])
def analyze_ingredients():
    data = request.get_json()
    ingredients = data.get('ingredients')

    if not ingredients:
        return jsonify({"error": "No ingredients provided"}), 400

    try:
        # Call Nutritionix API
        nutritionix_response = requests.post(
            'https://trackapi.nutritionix.com/v2/natural/nutrients',
            headers={
                'x-app-id': NUTRITIONIX_APP_ID,
                'x-app-key': NUTRITIONIX_API_KEY,
                'Content-Type': 'application/json'
            },
            json={'query': ingredients}
        )

        if nutritionix_response.status_code != 200:
            return jsonify({"error": "Failed to fetch data from Nutritionix API"}), 500

        nutrition_data = nutritionix_response.json()
        
        percentages = {
            'carbohydrates': 0,
            'fats': 0,
            'protein': 0,
            'vitamins': 0,  # Custom logic needed for vitamins
            'minerals': 0   # Custom logic needed for minerals
        }

        for food in nutrition_data.get('foods', []):
            percentages['carbohydrates'] += food.get('nf_total_carbohydrate', 0)
            percentages['fats'] += food.get('nf_total_fat', 0)
            percentages['protein'] += food.get('nf_protein', 0)

        # Call OpenAI to generate pros and cons
        openai.api_key = OPENAI_API_KEY
        prompt = f"""
        List 5 pros and 5 cons of the following ingredients: {ingredients}
        Return them in this format: 
        Pros: 
        1. Pro 1 
        2. Pro 2 
        3. Pro 3 
        4. Pro 4 
        5. Pro 5 
        Cons: 
        1. Con 1 
        2. Con 2 
        3. Con 3 
        4. Con 4 
        5. Con 5
        """
        
        openai_response = openai.Completion.create(
            model="text-davinci-003",
            prompt=prompt,
            max_tokens=150
        )

        pros_cons_text = openai_response['choices'][0]['text']
        pros = []
        cons = []

        if "Pros:" in pros_cons_text and "Cons:" in pros_cons_text:
            pros_text = pros_cons_text.split('Pros:')[1].split('Cons:')[0]
            cons_text = pros_cons_text.split('Cons:')[1]
            pros = pros_text.strip().split('\n')[:5]
            cons = cons_text.strip().split('\n')[:5]

        return jsonify({
            'percentages': percentages,
            'pros': pros,
            'cons': cons
        })
    
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
